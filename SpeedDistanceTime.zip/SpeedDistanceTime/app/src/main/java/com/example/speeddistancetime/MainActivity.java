package com.example.speeddistancetime;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        buttonListener();
    }

    public void buttonListener()
    {
        LinearLayout speed = (LinearLayout)findViewById(R.id.CalculateSpeed);
        speed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent speed_page = new Intent(MainActivity.this, Speed.class);
                startActivity(speed_page);
            }
        });

        LinearLayout distance = (LinearLayout)findViewById(R.id.CalculateDistance);
        distance.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent distance_page = new Intent(MainActivity.this, Distance.class);
                startActivity(distance_page);
            }
        });

        LinearLayout time = (LinearLayout)findViewById(R.id.CalculateTime);
        time.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent time_page = new Intent(MainActivity.this, Time.class);
                startActivity(time_page);
            }
        });

    }

}