package com.example.speeddistancetime;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.*;

import java.text.DecimalFormat;

public class Distance extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_distance);
        calculateDistance();
    }

    public void calculateDistance()
    {
        Button distanceBtn = (Button)findViewById(R.id.buttonDistance);
        distanceBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double speed = 0, time = 0;

                //SPEED
                final EditText speedText = (EditText)findViewById(R.id.SpeedInputD);
                String speedStr = speedText.getText().toString();

                if(speedStr.isEmpty())
                {
                    speedText.setError("Speed is required");
                }
                else
                {
                    speed = Double.parseDouble(speedStr);
                }

                //TIME
                final EditText timeText = (EditText)findViewById(R.id.TimeInputD);
                String timeStr = timeText.getText().toString();

                if(timeStr.isEmpty())
                {
                    timeText.setError("Time is required");
                }
                else
                {
                    time = Double.parseDouble(timeStr);
                }

                if(!speedStr.isEmpty() && !timeStr.isEmpty())
                {
                    //CALCULATE DISTANCE
                    double distance = speed * time;
                    DecimalFormat df = new DecimalFormat("#.##");
                    double distanceDbl = Double.parseDouble(df.format(distance));

                    final EditText output = (EditText)findViewById(R.id.OutputDistance);
                    output.setText(Double.toString(distanceDbl));
                }

            }
        });
    }
}