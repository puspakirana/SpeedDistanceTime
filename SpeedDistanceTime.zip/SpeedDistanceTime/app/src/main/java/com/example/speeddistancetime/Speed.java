package com.example.speeddistancetime;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.*;

import java.text.DecimalFormat;

public class Speed extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_speed);
        calculateSpeed();
    }

    public void calculateSpeed()
    {
        Button speedBtn = (Button)findViewById(R.id.buttonSpeed);
        speedBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                double distance = 0, time = 0;

                //DISTANCE
                final EditText distanceText = (EditText)findViewById(R.id.DistanceInputS);
                String distanceStr = distanceText.getText().toString();

                if(distanceStr.isEmpty())
                {
                    distanceText.setError("Distance is required");
                }
                else
                {
                    distance = Double.parseDouble(distanceStr);
                }

                //TIME
                final EditText timeText = (EditText)findViewById(R.id.TimeInputS);
                String timeStr = timeText.getText().toString();

                if(timeStr.isEmpty())
                {
                    timeText.setError("Time is required");
                }
                else
                {
                    time = Double.parseDouble(timeStr);
                }

                if(!distanceStr.isEmpty() && !timeStr.isEmpty())
                {
                    //CALCULATE SPEED
                    double speed = distance / time;
                    DecimalFormat df = new DecimalFormat("#.##");
                    double speedDbl = Double.parseDouble(df.format(speed));

                    final EditText output = (EditText)findViewById(R.id.OutputSpeed);
                    output.setText(Double.toString(speedDbl));
                }

            }
        });
    }
}