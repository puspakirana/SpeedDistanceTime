package com.example.speeddistancetime;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.*;

import java.text.DecimalFormat;

public class Time extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_time);
        calculateTime();
    }

    public void calculateTime()
    {
        Button timeBtn = (Button)findViewById(R.id.buttonTime);
        timeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double distance = 0, speed = 0;

                //DISTANCE
                final EditText distanceText = (EditText)findViewById(R.id.DistanceInputT);
                String distanceStr = distanceText.getText().toString();

                if(distanceStr.isEmpty())
                {
                    distanceText.setError("Distance is required");
                }
                else
                {
                    distance = Double.parseDouble(distanceStr);
                }

                //SPEED
                final EditText speedText = (EditText)findViewById(R.id.SpeedInputT);
                String speedStr = speedText.getText().toString();

                if(speedStr.isEmpty())
                {
                    speedText.setError("Speed is required");
                }
                else
                {
                    speed = Double.parseDouble(speedStr);
                }

                if(!distanceStr.isEmpty() && !speedStr.isEmpty())
                {
                    //CALCULATE TIME
                    double time = distance / speed;
                    DecimalFormat df = new DecimalFormat("#.##");
                    double timeDbl = Double.parseDouble(df.format(time));

                    final EditText output = (EditText)findViewById(R.id.OutputTime);
                    output.setText(Double.toString(timeDbl));
                }

            }
        });
    }
}